# Pousada Wireframe (Next.js + Tailwind)

## Rodando localmente
```bash
npm install
npm run dev
```

## Export estático (opcional)
```bash
npm run build
npm run export
```

## Deploy (Vercel)
- Suba este projeto para um repositório no GitHub.
- No painel da Vercel, clique em **New Project** > **Import Git Repository**.
- Selecione o repositório e confirme. As configurações padrão já funcionam para Next.js.
